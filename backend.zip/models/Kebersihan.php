<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Kebersihan".
 *
 * @property int $rt
 * @property string $dusun
 */
class Kebersihan extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Kebersihan';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['rt', 'dusun'], 'required'],
            [['rt'], 'integer'],
            [['dusun'], 'string', 'max' => 11],
            [['rt'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'rt' => 'Rt',
            'dusun' => 'Dusun',
        ];
    }
}
