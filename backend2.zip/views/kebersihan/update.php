<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Kebersihan */

$this->title = 'Update Kebersihan: ' . $model->rt;
$this->params['breadcrumbs'][] = ['label' => 'Kebersihans', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->rt, 'url' => ['view', 'id' => $model->rt]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="kebersihan-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
